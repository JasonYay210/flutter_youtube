class Thumbnail { //interface to display thumbnails
  final String? url;
  final int? width;
  final int? height;

  Thumbnail({this.url, this.width, this.height});
}